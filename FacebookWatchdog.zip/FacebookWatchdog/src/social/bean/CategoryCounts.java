package social.bean;

public class CategoryCounts 
{

	int sportsCount;
	
	int educationCount;
	
	int entertainmentCount;
	
	int historyCount;
	
	int politicsCount;

	public int getSportsCount() {
		return sportsCount;
	}

	public void setSportsCount(int sportsCount) {
		this.sportsCount = sportsCount;
	}

	public int getEducationCount() {
		return educationCount;
	}

	public void setEducationCount(int educationCount) {
		this.educationCount = educationCount;
	}

	public int getEntertainmentCount() {
		return entertainmentCount;
	}

	public void setEntertainmentCount(int entertainmentCount) {
		this.entertainmentCount = entertainmentCount;
	}

	public int getHistoryCount() {
		return historyCount;
	}

	public void setHistoryCount(int historyCount) {
		this.historyCount = historyCount;
	}

	public int getPoliticsCount() {
		return politicsCount;
	}

	public void setPoliticsCount(int politicsCount) {
		this.politicsCount = politicsCount;
	}
	
	
	
	
}
