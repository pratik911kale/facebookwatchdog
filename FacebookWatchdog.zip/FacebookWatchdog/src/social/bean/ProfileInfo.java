package social.bean;

public class ProfileInfo 
{
     String email;
     String first;
     String last;
     String path;
     
     public String getEmail()
 	{
       	return email;
 	}
 	
 	public void setEmail(String email)
 	{
 		this.email = email;
 	}
 	
 	public String getfirst()
	{
      	return first;
	}
	
	public void setfirst(String first)
	{
		this.first = first;
	}
	
	public String getlast()
	{
      	return last;
	}
	
	public void setlast(String last)
	{
		this.last = last;
	}
	
	public String getpath()
	{
      	return path;
	}
	
	public void setpath(String path)
	{
		this.path = path;
	}
	
}
