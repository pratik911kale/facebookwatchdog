package social.bean;

public class ProfessionBean 
{
     String email;
     String profession;
     String qualification;
     String workIn;
     
     public String getEmail()
 	{
 	   return email;
 	}
     
 	public void setEmail(String email)
 	{
 	    this.email = email;
 	}
 	
 	 public String getProfession()
  	{
  	   return profession;
  	}
      
  	public void setProfession(String profession)
  	{
  	    this.profession = profession;
  	}
  	
  	 public String getQualification()
  	{
  	   return qualification;
  	}
      
  	public void setQualification(String qualification)
  	{
  	    this.qualification = qualification;
  	}
  	
  	public String getWorkIn()
  	{
  	   return workIn;
  	}
      
  	public void setWorkIn(String workIn)
  	{
  	    this.workIn = workIn;
  	}
}
