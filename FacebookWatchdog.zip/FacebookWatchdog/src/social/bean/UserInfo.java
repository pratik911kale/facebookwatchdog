package social.bean;

public class UserInfo 
{
	
	String first;
	String last;
	String password;
	String email;
	String phone;
	String local;
	String permanent;
	String dob;
	String gender;
	
	
	public String getFirst()
	{
	   return first;
	}
    
	public void setFirst(String first)
	{
	    this.first = first;
	}
	
	public String getLast()
	{
	   return last;
	}
    
	public void setLast(String second)
	{
	    this.last = second;
	    
	}
	
	public String getPassword()
	{
	   return password;
	}
    
	public void setPassword(String password)
	{
	    this.password = password;
	}
	
	public String getEmail()
	{
	   return email;
	}
    
	public void setEmail(String email)
	{
	    this.email = email;
	}
	
	public String getPhone()
	{
	   return phone;
	}
    
	public void setPhone(String phone)
	{
	    this.phone = phone;
	}
	
	public String getLocal()
	{
	   return local;
	}
    
	public void setLocal(String local)
	{
	    this.local = local;
	}
	
	public String getPermanent()
	{
	   return permanent;
	}
    
	public void setPermanent(String permanent)
	{
	    this.permanent = permanent;
	}
	
	public String getDOB()
	{
	   return dob;
	}
    
	public void setDOB(String dob)
	{
	    this.dob = dob;
	}
	
	public String getGender()
	{
	   return gender;
	}
    
	public void setGender(String gender)
	{
	    this.gender = gender;
	}
}
